INSERT INTO authority (id_authority,NOMBRE) VALUES 
(1,"ROLE_MGR"), 
(2,"ROLE_DEV") -- Dev es desarrollador y Mgr es gerente

INSERT INTO `role` (`ID_ROLE`, `NOMBRE`) VALUES 
('1', 'ROLE_MGR'), 
('2', 'ROLE_DEV')

INSERT INTO `estado` (`ID_ESTADO`, `NOMBRE`) VALUES 
('1', 'Recibido'),
('2', 'Planeacion'), 
('3', 'Ejecucion'), 
('4', '1Entrega'), 
('5', '2Entrega'), 
('6', '3Entrega'), 
('7', 'Despliegue'), 
('8', 'Produccion'), 
('9', 'Posproduccion'), 
('10', 'Final'), 
('11', 'Garantia')

INSERT INTO `usuario` (`ID_USUARIO`, `NOMBRE`, `USER`, `EMAIL`, `PASSWORD`, `ID_ROLE`, `ID_AUTHORITY`) VALUES 
('1', 'Dylan Perez', 'Dylan7p', 'dylan@dylan.com', '$2a$04$zPJxkY1dPhJnLPjD293pN.0UDsIUoCHIG1SsUgGFrmPOZEeyBJhtK', '1', '1'), 
('2', 'Esteban Larrotta', 'Esteban7p', 'esteban@esteban.com', '$2a$04$zPJxkY1dPhJnLPjD293pN.0UDsIUoCHIG1SsUgGFrmPOZEeyBJhtK', '2', '2'), 
('3', 'User User', 'user', 'user@user.com', '$2a$04$zPJxkY1dPhJnLPjD293pN.0UDsIUoCHIG1SsUgGFrmPOZEeyBJhtK', '2', '2'), 
('4', 'admin admin', 'admin', 'admin@admin.com', '$2a$04$zPJxkY1dPhJnLPjD293pN.0UDsIUoCHIG1SsUgGFrmPOZEeyBJhtK', '1', '1')

INSERT INTO `proyecto` (`ID_PROYECTO`, `NOMBRE`, `ID_CREADOR`, `ID_ESTADO`) VALUES 
(1, 'eCommerce', '4', '1'), 
(2, 'Landing page', '1', '3'), 
(3, 'Rastreador', '4', '6'), 
(4, 'Proyeccion', '1', '10')

INSERT INTO `historia` (`ID_HISTORIA`, `ID_ESTADO_HISTORIA`, `DETALLE_CRITERIO`, `ID_PROYECTO`) VALUES 
('1', '1', 'revisando requerimientos', '1'), 
('2', '4', 'primera entrega funcional', '2'), 
('3', '7', 'adquiriendo recursos cloud real time', '3'), 
('4', '10', 'contrato finalizado', '4')

INSERT INTO `tarea` (`ID_TAREA`, `ID_ESTADO_TAREA`, `ID_HISTORIA`, `DESCRIPCION`) VALUES 
('1', '3', '3', 'contratando SaaS'), 
('2', '10', '4', 'Finalizado'), 
('3', '11', '1', 'revisando fallo en requerimiento'), 
('4', '1', '1', 'Se acepta el proyecto')

INSERT INTO `usuario_proyecto` (`ID_USUARIO_PROYECTO`, `USUARIO`, `PROYECTO`) VALUES 
('1', '3', '1'), 
('2', '2', '1'), 
('3', '2', '4'), 
('4', '3', '2')

