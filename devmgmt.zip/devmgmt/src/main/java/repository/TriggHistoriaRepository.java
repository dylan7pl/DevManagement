package repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import model.HistoriaModel;
import model.TareaModel;
import model.TriggHistoriaModel;
import model.TriggTareaModel;
import model.UsuarioModel;


@Repository
public interface TriggHistoriaRepository extends JpaRepository<TriggHistoriaModel, Long> {

	public List<TriggHistoriaModel> findByCambiador(UsuarioModel usuario);
	
	public List<TriggHistoriaModel> findByHistoria(HistoriaModel historia);

}
