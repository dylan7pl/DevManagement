package repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import model.EstadoModel;
import model.HistoriaModel;
import model.ProyectoModel;


@Repository
public interface HistoriaRepository extends JpaRepository<HistoriaModel, Long> {

	public List<HistoriaModel> findByEstado(EstadoModel estado);
	
	public List<HistoriaModel> findByProyecto(ProyectoModel proyecto);


}
