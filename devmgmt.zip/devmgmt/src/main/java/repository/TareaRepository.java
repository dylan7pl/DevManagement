package repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import model.EstadoModel;
import model.HistoriaModel;
import model.TareaModel;


@Repository
public interface TareaRepository extends JpaRepository<TareaModel, Long> {

	public List<TareaModel> findByEstado(EstadoModel estado);
	
	public List<TareaModel> findByHistoria(HistoriaModel historia);

}
