package repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import model.TareaModel;
import model.TriggTareaModel;
import model.UsuarioModel;


@Repository
public interface TriggTareaRepository extends JpaRepository<TriggTareaModel, Long> {

	public List<TriggTareaModel> findByCambiador(UsuarioModel usuario);
	
	public List<TriggTareaModel> findByTarea(TareaModel tarea);

}
