package repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import model.EstadoModel;
import model.HistoriaModel;
import model.ProyectoModel;
import model.UsuarioModel;
import model.UsuarioProyectoModel;


@Repository
public interface UsuarioProyectoRepository extends JpaRepository<UsuarioProyectoModel, Long> {

	public List<UsuarioProyectoModel> findByUsuario(UsuarioModel usuario);
	
	public List<UsuarioProyectoModel> findByProyecto(ProyectoModel proyecto);


}
