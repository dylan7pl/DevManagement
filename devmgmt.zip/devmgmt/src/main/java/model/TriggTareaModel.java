package model;


import java.io.Serializable;
import java.sql.Timestamp;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import jakarta.persistence.JoinColumn;

@Data
@Entity
@Table(name = "Trigg_Tarea")
public class TriggTareaModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long id_trigg_tarea;
	
	@ManyToOne
	@JoinColumn(name="id_usuario")
	private UsuarioModel cambiador;
	
	@ManyToOne
	@JoinColumn(name="id_tarea")
	private TareaModel tarea;
	
	@Column
	private Timestamp h_cambio; // este usa java.sql.Timestamp
	
	@Column
	private String prev_desc;
	
	public TriggTareaModel() {
		super();
	}

	public TriggTareaModel(Long id_trigg_tarea, UsuarioModel cambiador, TareaModel tarea, Timestamp h_cambio,
			String prev_desc) {
		super();
		this.id_trigg_tarea = id_trigg_tarea;
		this.cambiador = cambiador;
		this.tarea = tarea;
		this.h_cambio = h_cambio;
		this.prev_desc = prev_desc;
	}
	
	
	

}