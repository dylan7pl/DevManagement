package model;


import java.util.List;
import java.io.Serializable;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Transient;
import lombok.Data;

import jakarta.persistence.JoinColumn;

@Data
@Entity
@Table(name = "Usuario")
public class UsuarioModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long id_usuario;
	
	@Column
	private String nombre;
	
	@Column
	private String password;
	
	// Esta columna no se va a crear en la DB, solo es temporal para doble verificarla si es necesario
	// Esta columna no necesita getter ni setter
	@Transient
	private String confirmPassword;
	
	@Column(unique = true, nullable = false)
	private String username;
	
	@Column(unique = true, nullable = false)
	private String email;
	
	
	@ManyToMany(fetch = FetchType.LAZY)
	@JoinTable(name= "USER_role",
			joinColumns=@JoinColumn(name="id_username"),
			inverseJoinColumns = @JoinColumn(name="id_role"))
	private List<RoleModel> roles;
	
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name="authorities_users",
	joinColumns=@JoinColumn(name="id_usuario"),
	inverseJoinColumns=@JoinColumn(name="id_authority"))
	private Set<AuthorityModel> authorityModel;

	public UsuarioModel() {
		super();
	}
	
	

	public UsuarioModel(Long id_usuario, String nombre, String password, String confirmPassword, String username,
			String email, List<RoleModel> roles, Set<AuthorityModel> authorityModel) {
		super();
		this.id_usuario = id_usuario;
		this.nombre = nombre;
		this.password = password;
		this.confirmPassword = confirmPassword;
		this.username = username;
		this.email = email;
		this.roles = roles;
		this.authorityModel = authorityModel;
	}


	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public List<RoleModel> getRoles() {
		return roles;
	}

	public void setRoles(List<RoleModel> roles) {
		this.roles = roles;
	}

	public Set<AuthorityModel> getAuthority() {
		return authorityModel;
	}

	public void setAuthority(Set<AuthorityModel> authorityModel) {
		this.authorityModel = authorityModel;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	



}