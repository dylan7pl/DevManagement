package model;


import java.io.Serializable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import jakarta.persistence.JoinColumn;

@Data
@Entity
@Table(name = "Tarea")
public class TareaModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long id_tarea;
	
	@ManyToOne
	@JoinColumn(name="id_historia")
	private HistoriaModel historia;
	
	@ManyToOne
	@JoinColumn(name="id_estado")
	private EstadoModel estado;
	
	@Column
	private String descripcion;
	
	public TareaModel() {
		super();
	}

	public TareaModel(Long id_tarea, HistoriaModel historia, EstadoModel estado, String descripcion) {
		super();
		this.id_tarea = id_tarea;
		this.historia = historia;
		this.estado = estado;
		this.descripcion = descripcion;
	}

	public Long getId_tarea() {
		return id_tarea;
	}

	public void setId_tarea(Long id_tarea) {
		this.id_tarea = id_tarea;
	}

	public HistoriaModel getHistoria() {
		return historia;
	}

	public void setHistoria(HistoriaModel historia) {
		this.historia = historia;
	}

	public EstadoModel getEstado() {
		return estado;
	}

	public void setEstado(EstadoModel estado) {
		this.estado = estado;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	
	

}