package model;


import java.io.Serializable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import jakarta.persistence.JoinColumn;

@Data
@Entity
@Table(name = "UsuarioProyecto")
public class UsuarioProyectoModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long id_usuarioProyecto;
	
	@ManyToOne
	@JoinColumn(name="id_usuario")
	private UsuarioModel usuario;
	
	@ManyToOne
	@JoinColumn(name="id_proyecto")
	private ProyectoModel proyecto;
	
	public UsuarioProyectoModel() {
		super();
	}

	public UsuarioProyectoModel(Long id_usuarioProyecto, UsuarioModel usuario, ProyectoModel proyecto) {
		super();
		this.id_usuarioProyecto = id_usuarioProyecto;
		this.usuario = usuario;
		this.proyecto = proyecto;
	}
	
	
	

}