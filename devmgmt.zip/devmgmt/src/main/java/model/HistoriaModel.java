package model;


import java.io.Serializable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import jakarta.persistence.JoinColumn;

@Data
@Entity
@Table(name = "Historia")
public class HistoriaModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long id_historia;
	
	@Column
	private String detalleCriterio;
	
	@ManyToOne
	@JoinColumn(name="id_proyecto")
	private ProyectoModel proyecto;
	
	@ManyToOne
	@JoinColumn(name="id_estado")
	private EstadoModel estado;
	
	public HistoriaModel() {
		super();
	}

	public HistoriaModel(Long id_historia, String detalleCriterio, ProyectoModel proyecto, EstadoModel estado) {
		super();
		this.id_historia = id_historia;
		this.detalleCriterio = detalleCriterio;
		this.proyecto = proyecto;
		this.estado = estado;
	}

	public Long getId_historia() {
		return id_historia;
	}

	public void setId_historia(Long id_historia) {
		this.id_historia = id_historia;
	}

	public String getDetalleCriterio() {
		return detalleCriterio;
	}

	public void setDetalleCriterio(String detalleCriterio) {
		this.detalleCriterio = detalleCriterio;
	}

	public ProyectoModel getProyecto() {
		return proyecto;
	}

	public void setProyecto(ProyectoModel proyecto) {
		this.proyecto = proyecto;
	}

	public EstadoModel getEstado() {
		return estado;
	}

	public void setEstado(EstadoModel estado) {
		this.estado = estado;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
	
	

}