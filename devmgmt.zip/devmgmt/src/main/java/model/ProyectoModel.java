package model;


import java.io.Serializable;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import jakarta.persistence.JoinColumn;

@Data
@Entity
@Table(name = "Proyecto")
public class ProyectoModel implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(unique = true, nullable = false)
	private Long id_proyecto;
	
	@Column
	private String nombre;
	
	@ManyToOne
	@JoinColumn(name="id_depto")
	private UsuarioModel usuario;
	
	@ManyToOne
	@JoinColumn(name="id_estado")
	private EstadoModel estado;
	
	public ProyectoModel() {
		super();
	}

	public ProyectoModel(Long id_proyecto, String nombre, UsuarioModel usuario, EstadoModel estado) {
		super();
		this.id_proyecto = id_proyecto;
		this.nombre = nombre;
		this.usuario = usuario;
		this.estado = estado;
	}
	
	
	

}