package controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.annotation.Secured;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import service.HistoriaService;
import service.ProyectoService;
import service.TareaService;
import service.TriggHistoriaService;
import service.UsuarioService;

import model.HistoriaModel;
import model.ProyectoModel;
import model.TareaModel;
import repository.RoleRepository;

@RestController
@RequestMapping(path = "/api/v1/")
public class MainController {

	@Autowired
	UsuarioService UsuarioService;
	
	@Autowired
	ProyectoService proyectoService;
	
	@Autowired
	TareaService tareaService;
	
	@Autowired
	HistoriaService historiaService;
	
	@Autowired
	TriggHistoriaService triggHistoriaService;
	
	@GetMapping({"/api/v1/","/"})
	public List<ProyectoModel> index() {
		List<String> lista = new ArrayList<>();
		lista.add("Hubo un fallo al listar los proyectos");
		try {
			return proyectoService.getProyectos() ;
		} catch (Exception e) {
			return (List) e; // se obliga la conversionde String a List
		}
	}
	
	@GetMapping({"/api/v1/","/"})
	@Secured({"ROLE_MGR","ROLE_DEV"})
	public List<ProyectoModel> inicio() {
		List<String> lista = new ArrayList<>();
		lista.add("Hubo un fallo al listar los proyectos");
		try {
			
			return proyectoService.getProyectos() ;
		} catch (Exception e) {
			return (List) e; // se obliga la conversionde String a List
		}
	}
	
	
	@GetMapping("/actualizarProyecto/{id}")
	@Secured("ROLE_MGR")
	public void editProyecto(Model model, @PathVariable(name ="id")Long id) throws Exception{
		Optional<ProyectoModel> proyectoToEdit = proyectoService.getProyectos(id);

	}
	
	@GetMapping("/crearProyecto/{proyecto}")
	@Secured("ROLE_MGR")
	public void crearProyecto(Model model, @PathVariable(name ="proyecto") ProyectoModel proyecto)throws Exception{
		
		try {
			proyectoService.saveOrUpdate(proyecto);
		} catch (Exception e) {
			throw (e);
		}
		
	}
	
	@GetMapping("/actualizarTarea/{tarea}")
	@Secured({"ROLE_MGR","ROLE_DEV"})
	public void actualizarTarea(Model model, @PathVariable(name ="proyecto") TareaModel tarea)throws Exception{
		
		try {
			tareaService.getTareas(tarea.getId_tarea());
			// Aqui deberia guardar el trigger al encontrar la tarea antes de actualizarla

			tareaService.saveOrUpdate(tarea);
		} catch (Exception e) {
			throw (e);
		}
		
	}
	
	@GetMapping("/actualizarHistoria/{historia}")
	@Secured("ROLE_MGR")
	public void actualizarHistoria(Model model, @PathVariable(name ="proyecto") HistoriaModel historia)throws Exception{
		
		try {
			historiaService.getHistorias(historia.getId_historia());
			// Aqui deberia ir el trigger al encontrar la tarea antes de actualizarla
			historiaService.saveOrUpdate(historia);
		} catch (Exception e) {
			throw (e);
		}
		
	}
	
	
}


