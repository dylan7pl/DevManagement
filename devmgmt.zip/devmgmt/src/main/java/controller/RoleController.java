package controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import model.RoleModel;
import service.RoleService;


@RestController
@RequestMapping(path = "/api/v1/roles")
public class RoleController {
	
	@Autowired
	private RoleService roleService;
	
	@GetMapping
	public List<RoleModel> getAll() {
		return roleService.getRoles();
	}
	
	@GetMapping("/all")
	public List<RoleModel> getAllRoles() {
		return roleService.getRoles();
	}
	
	@GetMapping("/")
	public Optional<RoleModel> getbyId(@PathVariable("roleId") Long roleId) {
		return roleService.getRoles(roleId);
	}
	
	@PostMapping
	public void saveUpdate(@RequestBody RoleModel role) {
		roleService.saveOrUpdate(role);
	}
	
	@DeleteMapping("/{roleId}")
	public void saveUpdate(@PathVariable Long roleId) {
		roleService.delete(roleId);
	}

}
