package controller;



import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import model.UsuarioModel;
import service.UsuarioService;


@RestController
@RequestMapping(path = "/api/v1/Usuarios")
public class UsuarioController {
	
	@Autowired
	private UsuarioService UsuarioService;
	
	@GetMapping
	public List<UsuarioModel> getAll() {
		return UsuarioService.getUsuarios();
	}
	
	@GetMapping("/all")
	public List<UsuarioModel> getAllUsuarios() {
		return UsuarioService.getUsuarios();
	}
	
	@GetMapping("/")
	public Optional<UsuarioModel> getbyId(@PathVariable("UsuarioId") Long UsuarioId) {
		return UsuarioService.getUsuarios(UsuarioId);
	}
	
	@PostMapping
	public void saveUpdate(@RequestBody UsuarioModel Usuario) {
		UsuarioService.saveOrUpdate(Usuario);
	}
	
	@DeleteMapping("/{UsuarioId}")
	public void saveUpdate(@PathVariable Long UsuarioId) {
		UsuarioService.delete(UsuarioId);
	}

}

