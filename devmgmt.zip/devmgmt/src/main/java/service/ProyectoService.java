package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.EstadoModel;
import model.ProyectoModel;
import repository.ProyectoRepository;

@Service
public class ProyectoService {

	@Autowired
	ProyectoRepository proyectoRepository;
	
	public List<ProyectoModel> getProyectos(){
		return proyectoRepository.findAll();
	}
	
	public Optional<ProyectoModel> getProyectos(Long id){
		return proyectoRepository.findById(id);
	}
	
	public List<ProyectoModel> getProyectosByEstado(EstadoModel estado) {
		return proyectoRepository.findByEstado(estado);
	}
	
	public void saveOrUpdate(ProyectoModel Proyecto) {
		proyectoRepository.save(Proyecto);
	}
	
	public void delete(Long id) {
		proyectoRepository.deleteById(id);
	}

}
