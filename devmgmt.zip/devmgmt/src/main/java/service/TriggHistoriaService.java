package service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import model.HistoriaModel;
import model.TriggHistoriaModel;
import model.UsuarioModel;
import repository.TriggHistoriaRepository;

@Service
public class TriggHistoriaService {

	@Autowired
	TriggHistoriaRepository triggHistoriaRepository;
	
	public List<TriggHistoriaModel> getTriggHistorias(){
		return triggHistoriaRepository.findAll();
	}
	
	public Optional<TriggHistoriaModel> getTriggHistorias(Long id){
		return triggHistoriaRepository.findById(id);
	}
	
	public List<TriggHistoriaModel> getTriggHistoriasByCambiador(UsuarioModel usuario) {
		return triggHistoriaRepository.findByCambiador(usuario);
	}
	
	public List<TriggHistoriaModel> getTriggHistoriasByHistoria(HistoriaModel historia) {
		return triggHistoriaRepository.findByHistoria(historia);
	}
	
	public void saveOrUpdate(TriggHistoriaModel TriggHistoria) {
		triggHistoriaRepository.save(TriggHistoria);
	}
	
	public void delete(Long id) {
		triggHistoriaRepository.deleteById(id);
	}

}
