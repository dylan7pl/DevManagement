package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.AuthorityModel;
import repository.AuthorityRepository;

@Service
public class AuthorityService {

	@Autowired
	AuthorityRepository authorityRepository;
	
	public List<AuthorityModel> getAuthoritys(){
		return authorityRepository.findAll();
	}
	
	public Optional<AuthorityModel> getAuthoritys(Long id){
		return authorityRepository.findById(id);
	}
	
	public void saveOrUpdate(AuthorityModel authority) {
		authorityRepository.save(authority);
	}
	
	public void delete(Long id) {
		authorityRepository.deleteById(id);
	}

}
