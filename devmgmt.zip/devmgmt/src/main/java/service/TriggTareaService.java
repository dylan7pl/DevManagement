package service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import model.TareaModel;
import model.TriggTareaModel;
import model.UsuarioModel;
import repository.TriggTareaRepository;

@Service
public class TriggTareaService {

	@Autowired
	TriggTareaRepository triggTareaRepository;
	
	public List<TriggTareaModel> getTriggTareas(){
		return triggTareaRepository.findAll();
	}
	
	public Optional<TriggTareaModel> getTriggTareas(Long id){
		return triggTareaRepository.findById(id);
	}
	
	public List<TriggTareaModel> getTriggTareasByCambiador(UsuarioModel usuario) {
		return triggTareaRepository.findByCambiador(usuario);
	}
	
	public List<TriggTareaModel> getTriggTareasByTarea(TareaModel tarea) {
		return triggTareaRepository.findByTarea(tarea);
	}
	
	public void saveOrUpdate(TriggTareaModel TriggTarea) {
		triggTareaRepository.save(TriggTarea);
	}
	
	public void delete(Long id) {
		triggTareaRepository.deleteById(id);
	}

}
