package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.EstadoModel;
import repository.EstadoRepository;

@Service
public class EstadoService {

	@Autowired
	EstadoRepository estadoRepository;
	
	public List<EstadoModel> getEstados(){
		return estadoRepository.findAll();
	}
	
	public Optional<EstadoModel> getEstados(Long id){
		return estadoRepository.findById(id);
	}
	
	public void saveOrUpdate(EstadoModel estado) {
		estadoRepository.save(estado);
	}
	
	public void delete(Long id) {
		estadoRepository.deleteById(id);
	}

}
