package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.EstadoModel;
import model.HistoriaModel;
import repository.HistoriaRepository;
import repository.TriggHistoriaRepository;

@Service
public class HistoriaService {

	@Autowired
	HistoriaRepository historiaRepository;
	TriggHistoriaRepository triggHistoriaRepository;
	
	public List<HistoriaModel> getHistorias(){
		return historiaRepository.findAll();
	}
	
	public Optional<HistoriaModel> getHistorias(Long id){
		return historiaRepository.findById(id);
	}
	
	public List<HistoriaModel> getHistoriasByEstado(EstadoModel estado) {
		return historiaRepository.findByEstado(estado);
	}
	
	public void saveOrUpdate(HistoriaModel historia) {
		historiaRepository.save(historia);
	}
	
	public void delete(Long id) {
		historiaRepository.deleteById(id);
	}

}
