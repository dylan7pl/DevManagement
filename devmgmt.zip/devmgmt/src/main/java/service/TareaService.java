package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.EstadoModel;
import model.HistoriaModel;
import model.TareaModel;
import repository.TareaRepository;

@Service
public class TareaService {

	@Autowired
	TareaRepository tareaRepository;
	
	public List<TareaModel> getTareas(){
		return tareaRepository.findAll();
	}
	
	public Optional<TareaModel> getTareas(Long id){
		return tareaRepository.findById(id);
	}
	
	public List<TareaModel> getTareasByEstado(EstadoModel estado) {
		return tareaRepository.findByEstado(estado);
	}
	
	public List<TareaModel> getTareasByHistoria(HistoriaModel historia) {
		return tareaRepository.findByHistoria(historia);
	}
	
	public void saveOrUpdate(TareaModel tarea) {
		tareaRepository.save(tarea);
	}
	
	public void delete(Long id) {
		tareaRepository.deleteById(id);
	}

}
