package service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import model.UsuarioModel;
import repository.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	UsuarioRepository UsuarioRepository;
	
	public List<UsuarioModel> getUsuarios(){
		return UsuarioRepository.findAll();
	}
	
	public Optional<UsuarioModel> getUsuarios(Long id){
		return UsuarioRepository.findById(id);
	}
	
	public void saveOrUpdate(UsuarioModel Usuario) {
		UsuarioRepository.save(Usuario);
	}
	
	public void delete(Long id) {
		UsuarioRepository.deleteById(id);
	}

}
