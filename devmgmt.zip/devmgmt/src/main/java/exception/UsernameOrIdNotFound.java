package exception;

public class UsernameOrIdNotFound extends Exception {

	/**
	 * por si no se encuentra el usuario
	 * buscar en la db si ya fue agregado al menos un gerente manualmente
	 */
	private static final long serialVersionUID = 1668398822129870029L;

	public UsernameOrIdNotFound() {
		super("Usuario o Id no encontrado");
	}
	
	public UsernameOrIdNotFound(String message) {
		super(message);
	}
}
