package com.DevMgmt.devmgmt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DevmgmtApplication {

	public static void main(String[] args) {
		SpringApplication.run(DevmgmtApplication.class, args);
	}

}
