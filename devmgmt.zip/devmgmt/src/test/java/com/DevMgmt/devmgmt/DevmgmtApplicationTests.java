package com.DevMgmt.devmgmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevmgmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
